#!/usr/bin/env bash
# Install script for most-racist-rice-V2
# Usage: ./install.sh [--deps] [--wm hypr|mango|both]
#   --deps   also install packages (pacman/Arch-based only)
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CFG="${XDG_CONFIG_HOME:-$HOME/.config}"
BACKUP="$CFG/rice-backup-$(date +%Y%m%d-%H%M%S)"
DEPS=0
WM=both

while [ $# -gt 0 ]; do
  case "$1" in
    --deps) DEPS=1 ;;
    --wm) WM="${2:-both}"; shift ;;
    -h|--help) sed -n '2,5p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
  shift
done

if [ "$DEPS" = 1 ]; then
  if command -v pacman >/dev/null; then
    sudo pacman -S --needed kitty fish waybar fuzzel rofi neovim fastfetch \
      swaybg pamixer playerctl grim slurp satty flameshot hyprlock \
      ttf-jetbrains-mono-nerd bc
    echo "Note: install hyprland / mango, librewolf and spotify yourself if you want them."
  else
    echo "--deps supports pacman only. Install these manually:"
    echo "kitty fish waybar fuzzel rofi neovim fastfetch swaybg pamixer playerctl grim slurp satty flameshot bc JetBrainsMono Nerd Font"
  fi
fi

backup_and_copy() {
  local name="$1"
  [ -e "$SRC/$name" ] || return 0
  if [ -e "$CFG/$name" ]; then
    mkdir -p "$BACKUP/$(dirname "$name")"
    mv "$CFG/$name" "$BACKUP/$name"
    echo "backup: $CFG/$name -> $BACKUP/$name"
  fi
  mkdir -p "$CFG/$(dirname "$name")"
  cp -r "$SRC/$name" "$CFG/$name"
  echo "installed: $name"
}

for d in kitty gtk-3.0 gtk-4.0 rofi fuzzel waybar nvim wallpaper fastfetch; do
  backup_and_copy "$d"
done
backup_and_copy userChrome.css

case "$WM" in
  hypr|both)  backup_and_copy hypr ;;
esac
case "$WM" in
  mango|both) backup_and_copy mango ;;
esac

chmod +x "$CFG"/waybar/scripts/*.sh

# Waycat / Skulltype fonts for the waybar animations
mkdir -p "$HOME/.local/share/fonts"
cp "$CFG"/waybar/scripts/fonts/*.ttf "$HOME/.local/share/fonts/"
fc-cache -f

echo
echo "Done. Things to check manually:"
echo " - monitor resolution/refresh rate in hypr/hyprland.lua and mango/config.conf (default 1920x1080@144)"
echo " - kitty uses fish: install it or edit 'shell' in kitty/kitty.conf"
echo " - LibreWolf: copy userChrome.css into your profile's chrome/ folder (not ~/.config)"
echo " - restart waybar: pkill waybar; waybar &"
[ -d "$BACKUP" ] && echo " - old configs saved in $BACKUP"
